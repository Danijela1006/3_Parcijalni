package org.example.service;

import org.example.dto.UpisDto;

import java.util.List;

public interface UpisService {
    List<UpisDto> getAllUpisi();
}
