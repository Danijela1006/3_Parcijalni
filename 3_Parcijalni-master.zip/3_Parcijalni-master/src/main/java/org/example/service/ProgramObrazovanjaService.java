package org.example.service;

import org.example.dto.ProgramObrazovanjaDto;

import java.util.List;

public interface ProgramObrazovanjaService {
    List<ProgramObrazovanjaDto> getAllPorgramObrazovanja();

}
